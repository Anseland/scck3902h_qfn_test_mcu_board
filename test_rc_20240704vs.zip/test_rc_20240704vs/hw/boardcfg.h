
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __BOARDCFG_H__
#define __BOARDCFG_H__

#include "Appcfg.h"

#define STM32F10x


#endif /* __BOARDCFG_H__ */
