
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __APPCFG_H__
#define __APPCFG_H__

#define  BRD_10DoF100_CASBJ
#include "ProjectCfg.h"


#endif /* __APPCFG_H__ */
