/* Copyright (c) MEMSPlus. All Rights Reserved.
 *
 */

#ifndef __PROJECTCFG_H__
#define __PROJECTCFG_H__

#define DP_TIMER_IRQ_PP							1
#define DP_TIMER_IRQ_SP							0
#define RS232_USART_IRQ_PP						0
#define RS232_USART_IRQ_SP						0

#define USE_CMSIS_TIMER_DELAY
//#define USE_HSI

#define HW_VER  "SiP100"
#define SW_VER	"100"

#define CLI_ENABLE
#define CLI_CMD_END_CHAR		                0xD
#define CLI_CMD_BUF_LEN			                1000
#define CLI_ARGS_NUM_MAX		                10


#endif /* !__PROJECTCFG_H__ */