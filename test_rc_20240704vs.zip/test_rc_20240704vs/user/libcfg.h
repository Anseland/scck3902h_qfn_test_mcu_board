
#ifndef __LIBCFG_H__
#define __LIBCFG_H__

#include "boardcfg.h"

#define STM32F10x

#if defined STM32F10x
#include "stm32f10x.h"

#else
#error "<-- !No defined lib! -->"
#endif

#endif /* !__LIBCFG_H__ */