/*******************************************************************************
* �ļ���          	: main.c
* ����             : Losingamong
* ��������  		: 14/09/2010
* ����		     : ������
*******************************************************************************/
/* ͷ�ļ�    -----------------------------------------------------------------*/
#include "stm32f10x.h"
#include "usart.h"
#include "stm32f10x_usart.h"
#include "CLI.h"
#include "Delay.h"
#include "SPI_GPIO.h"
#include "SPI.h"
#include "board.h"
#include "stm32f10x_adc.h"
#include <stdlib.h>
#include <string.h>


/* �Զ���ͬ��ؼ���    -------------------------------------------------------*/


/* �Զ��������        -------------------------------------------------------*/
#define Delay(n)        while((n)--)
#define FLASHADDR_BASE  0x8005000
#define SYSTIME_OFS     0x00
#define SYSRIME_SIZE    7

#define RD      0x00                    //Read Flag: bit7=0
#define WR      0x80                    //Write Flag: bit7=1

#define CMD_NUM 17                      //number of command
#define CMD_TIMEOUT     10000000        //time out number for SPI communication

#define CMD_CODE_DT     0x04            //CMD Code for Date Time Data
#define DET_0   0x00                    //0x00: ���źű�־��0x00���д��źţ�������ֵ
#define DET_1   0x01                    //0x01: ���źű�־��0x01: �޴��źţ�С����ֵ

/* �Զ��庯����        -------------------------------------------------------*/

/**/
static char * CMD[CMD_NUM]=
{
    "TH",       "MD",   "PW",   "DT",   "PRD",  "DET",  "UD",   "DD",   "P1",   "P2",   "PRD2", "AD",   "ADCEN",        "REF1",        "REF2",  "AD1",  "AD2"
};
static u8 CMD_CODE[CMD_NUM]=
{
    0x01,       0x02,   0x03,   0x04,   0x05,   0x06,   0x07,   0x08,   0x09,   0x0a,   0x0b,   0x0c,   0x0d,           0x0e,           0x0f,   0x20,   0x21
};

static u16      sz[CMD_NUM]=
{
    4,          1,      1,      7,      2,      1,      16,    48,    4,      4,     2,      1,      1,               2,              2,        1,      1
}; //�涨��������ռ�õ��ֽ���
static u8       Th[4];//={0xa1,0xe5,0xa4,0xf5};
static u8       Md;//=0x01;
static u16      Pw;//=0xfe05;
static u8       Dt[7];//={20,24,03,27,14,50,33};//"20240327145033";
static u16      Prd;//=0xfe05;
static u8       Det;//=0x00;
static u8       Ud[16];//={0xfe};
static u8       Dd[48];//={0};
static u8       Pp1[4];//={0};
static u8       Pp2[4];//={0};
static u16      Prd2;
static u8       Ad;
static u8       Ade;
static u16      Vref1;
static u16      Vref2;
static  u8      Ad1;
static  u8      Ad2;
//static u16      Vt;

static u8 * pDATA[CMD_NUM]; //ָ�����ݵ�ָ������

////////////////////////////////////////////////////////////////////////////////
void InitData(void)
{
    pDATA[0]=Th;        pDATA[1]=&Md;   pDATA[2]=(u8*)&Pw;      pDATA[3]=Dt;    pDATA[4]=(u8*)&Prd; 
    pDATA[5]=&Det;      pDATA[6]=Ud;    pDATA[7]=Dd;            pDATA[8]=Pp1;   pDATA[9]=Pp2;
    pDATA[10]=(u8*)&Prd2;
    pDATA[11]=&Ad;
    pDATA[12]=&Ade;
    pDATA[13]=(u8*)&Vref1;
    pDATA[14]=(u8*)&Vref2;
    pDATA[15]=(u8*)&Ad1;
    pDATA[16]=(u8*)&Ad2;
    

    
    Th[0]=0x60;Th[1]=0x65;Th[2]=0x70;Th[3]=0x75;
    Md=0x00;
    
    u16 pw=20;                          //0.5us
    Pw=((pw&0xff00)>>8) | ((pw&0x00ff)<<8);
    
    Dt[0]=20; Dt[1]=24; Dt[2]=03; Dt[3]=27; Dt[4]=14; Dt[5]=50; Dt[6]=33;
    
    u16 prd=0x0002;                        //s
    Prd=((prd&0xff00)>>8) | ((prd&0x00ff)<<8);
    
    Det=0x00;
    for(int i=0;i<16;i++)
    {
        Ud[i]=0xfe;
    }
    for(int i=0;i<48;i++)
    {
        Dd[i]=0x00;
    }
    for(int i=0;i<4;i++)
    {
        Pp1[i]=0x00;
    }
    for(int i=0;i<4;i++)
    {
        Pp2[i]=0x00;
    }
    
    u16 prd2=0x0002;
    Prd2=((prd2&0xff00)>>8) | ((prd2&0x00ff)<<8);
    
    Ade=4;
    
    Vref1=0x170;
    Vref2=0x070;
    
    u16 vref=Vref1;                                     
    Vref1=((vref&0xff00)>>8) | ((vref&0x00ff)<<8);      //��������
    
    vref=Vref2;
    Vref2=((vref&0xff00)>>8) | ((vref&0x00ff)<<8);      //��������
 
}
//////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////
s8 CLI_CmdHandler_CLISystemReset(u8 argc, char *argv[])
{
//    mDelay(5000);
    Board_Reset();

    return 0;
}
//////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////
s8 CLI_CmdHandler_CLIReadMemory(u8 argc, char *argv[])
{
    u32 cnt = 0;
    u16 *p;
    do											   
    {
        p = (u16 *)(0x8005000 + cnt*2 );
        printf("\r\n��ȡ�ڲ�FLASH�õ�ַ�洢������Ϊ��0x%04x",*p);
        cnt++;
    }while(cnt < 6);
    printf("\n");

    return 0;
}
///////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////
//Write AiP��дEEPROM
s8 CLI_CmdHandler_CLIWriteAiP(u8 argc, char *argv[])
{
//    if(argc != 1)
//    {
//        return -1;
//    }

    //1.�ж������Ƿ���ȷ�����ڣ�
    u16 i=0;
    u8 nCode;
    for (i=0;i<CMD_NUM;i++)
    {
        if( !strcmp(CMD[i], argv[0]) )
        {
            nCode=i;
            break;
        }
    }
    if(i==CMD_NUM)
    {
        printf("Command not exist!\n");
        return -1;
    }
    

    //2.��������
    //2.1. ȷ�����������Ƿ���ȷ
    if(argc != 1+sz[nCode])
    {
        return -1;
    }
    //2.2. ���ַ���תΪ���ֲ���
    for(i=0;i<sz[nCode];i++)
    {
         pDATA[nCode][i]=(char)atoi(argv[1+i]);       //����1 תΪ���ݲ���
    }
       
    
    
    //3.���ʹ�������
    u32 n=CMD_TIMEOUT;
    
    CS_H;
    mDelay(100);
    CS_L;
    
    AIP_SPI_WB(WR|CMD_CODE[nCode]);
    //�����дʱ�������������Ӧ��ȷ�����źű�־�Ƿ����
    if(CMD_CODE[nCode]==CMD_CODE_DT)      
    {
          u8 ack;
          n=CMD_TIMEOUT;
          while(n>0)
          {
              if(!SDO)
              {
                   ack=AIP_SPI_RB();
                   break;
              }
              n--;
          }
          if(n==0)                      //��ʱ�˳�
          {
            CS_H;
            printf("SPI Timeout!\n");
          
            return -1;
          }
          if(ack==DET_0)                //�����źű�־δ���㣬ֱ�ӷ��أ�������
          {
            CS_H;
            printf("DET not reset, cannot upate the Time Stamp!\n");
           
            return -2;
          }
    }
    
    //д������   
    for(i=0;i<sz[nCode];i++)
    {
        
          n=CMD_TIMEOUT;
          while(n>0)
          {
              if(!SDO)
              {
                  AIP_SPI_WB((u8)pDATA[nCode][i]);
                  break;
              }
              n--;
          }
          if(n==0)
          {
            printf("SPI Timeout!\n");
            break;
          }
    }
    CS_H;
    
    if(n==0)
    {
        printf("Command not fullfiled correctly!!\n");
        return -1;
    }
    printf("\n - spi cmd>>: 0x%02x\n",WR|CMD_CODE[nCode]);
    for(int i=0;i<sz[nCode];i++)
    {
        printf(" - spi data>>[%d]: 0x%02x\n",i,pDATA[nCode][i]);
    }
 	
    return 0;
}
//END OF: Write AiP��дEEPROM
//END OF: s8 CLI_CmdHandler_CLIWriteAiP(u8 argc, char *argv[])
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//Read AiP
s8 CLI_CmdHandler_CLIReadAiP(u8 argc, char *argv[])
{
    if(argc != 1)
    {
        return -1;
    }

    u16 i=0;
    u8 nCode;
    for (i=0;i<CMD_NUM;i++)
    {
        if( !strcmp(CMD[i], argv[0]) )
        {
            nCode=i;
            break;
        }
    }
    if(i==CMD_NUM)
    {
        printf("Command not exist!\n");
        return -1;
    }
    
    u32 n=CMD_TIMEOUT;
    
    CS_H;
    mDelay(100);
    CS_L;
    
    AIP_SPI_WB(RD|CMD_CODE[nCode]);
   
    for(i=0;i<sz[nCode];i++)
    {
        
          n=CMD_TIMEOUT;
          while(n>0)
          {
              if(!SDO)
              {
                   pDATA[nCode][i]=AIP_SPI_RB();
                   break;
              }
              n--;
          }
          if(n==0)
          {
            printf("SPI Timeout!\n");
            break;
          }
    }
    CS_H;
    
    if(n==0)
    {
        printf("Command not fullfiled correctly!!\n");
        return -1;
    }
    printf("\nspi cmd>>: 0x%02x\n",CMD_CODE[nCode]);
    for(int i=0;i<sz[nCode];i++)
    {
      printf("spi data<<[%d]: 0x%02x\n",i,pDATA[nCode][i]);
    }
    
    return 0;
}
//END OF: //Read AiP
//END OF�� s8 CLI_CmdHandler_CLIReadAiP(u8 argc, char *argv[])
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//Read AiP in Test Mode
s8 CLI_CmdHandler_CLIReadAiP_TST(u8 argc, char *argv[])
{
    if(argc != 1)
    {
        return -1;
    }

    u16 i=0;
    u8 nCode;
    for (i=0;i<CMD_NUM;i++)
    {
        if( !strcmp(CMD[i], argv[0]) )
        {
            nCode=i;
            break;
        }
    }
    if(i==CMD_NUM)
    {
        printf("Command not exist!\n");
        return -1;
    }
    
    u32 n=CMD_TIMEOUT;
    
    CS_H;
    mDelay(100);
    CS_L;
    
    //1. ���Ϳ������� 
    AIP_SPI_WB(RD|CMD_CODE[nCode]);
    
    //2. ����ǲ�����ʼ�������SPI�����жϣ���SDO/RDY�źţ�����ʼ����
    //���յ��ź�֮��ͨ�����ڷ��͸���λ��
    //SDO/RDY��Ϊ�͵�ƽ��SPI Ready�󣩣���������

        
        
    
    //2. ����ǲ���ֹͣ����ڹر�SPI�����жϣ���SDO/RDY�źţ���ֹͣ����
    //ֹͣ���պ�CS�ø�
   
    for(i=0;i<sz[nCode];i++)
    {
        
          n=CMD_TIMEOUT;
          while(n>0)
          {
              if(!SDO)          //SDO/RDY��Ϊ�͵�ƽ��SPI Ready�󣩣���������
              {
                   pDATA[nCode][i]=AIP_SPI_RB();
                   break;
              }
              n--;
          }
          if(n==0)
          {
            printf("SPI Timeout!\n");
            break;
          }
    }
    CS_H;
    
    if(n==0)
    {
        printf("Command not fullfiled correctly!!\n");
        return -1;
    }
    printf("\nSent Command: R %s\n",CMD[nCode]);
    for(int i=0;i<sz[nCode];i++)
    {
      printf("Read Data[%d]: 0x%02x\n",i,pDATA[nCode][i]);
    }
    
    return 0;
}
//
///////////////////////////////////////////////////////////////////////////////



//////////////////////////////////////////////////////////////////////////////
//Set AiP Mode  "Md"
s8 CLI_CmdHandler_CLISetAiPMode(u8 argc, char *argv[])
{
    if(argc != 1)
    {
        return -1;
    }

    char md=*argv[0];
    if(md== '0')
    {
      Md=0;
      printf("\nMode = 0!\n");
    }
    else
    {
      Md=1;
      printf("\nMode = 1!\n");
    }
    
//    CLI_CmdHandler_CLIWriteAiP(1, (char*)CMD[1]);
 	
    return 0;
}
//
//////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//
s8 CLI_CmdHandler_CLIReadSPIReg8(u8 argc, char *argv[])
{
        AIP_RESET();
        u16 ID=Get_ID();
//        u8 fd=0x11;
//        fd=AIP_Read_Reg8(0x11);
        
        printf("\r\nADC ID��0x%04x\n",ID);

    return 0;
}
//
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
///
s8 CLI_CmdHandler_CLIReadSPIRegXByte(u8 argc, char *argv[])
{
    u8 cmd=0xC2;
    u8 data[4]={0xa1, 0xe5, 0xa9, 0xf5};
    u32 n=CMD_TIMEOUT;
    
    CS_H;
    mDelay(100);
    CS_L;
    
    AIP_SPI_WB(cmd);
  
    for(int i=0;i<4;i++)
    {
        n=CMD_TIMEOUT;
        while(n>0)
        {
            if(!SDO)
            {
                 data[i]=AIP_SPI_RB();
                 break;
            }
            n--;
        }
        if(n==0)
        {
          printf("SPI Timeout!\n");
               
          CS_H;
          return 0;
        }
    }
    CS_H;
    
    printf("\nSent Command: 0x%02x\n",cmd);    
    for(int i=0;i<4;i++)
    {
        printf("Read Data[%d]: 0x%02x n=%d\n",i,data[i],n);
    }
    
    return 0;
}
//
////////////////////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////////////////
s8 CLI_CmdHandler_CLIWriteSPIRegXByte(u8 argc, char *argv[])
{
    u8 cmd=0xc1;
    u8 data[4]={0xa1, 0xe5, 0xa9, 0xf5};
    
    u32 n=CMD_TIMEOUT;
    
    CS_H;
    mDelay(100);
    CS_L;
    
    AIP_SPI_WB(cmd);
   
    for(int i=0;i<4;i++)
    {
        n=CMD_TIMEOUT;
        while(n>0)
        {
            if(!SDO)
            {
                 AIP_SPI_WB(data[i]);
                 break;
            }
            n--;
        }
        if(n==0)
        {
          printf("SPI Timeout!\n");
               
          CS_H;
          return 0;
        }
    }
    CS_H;
    printf("\nSent Command: 0x%02x\n",cmd);
    for(int i=0;i<4;i++)
    {
        printf("Sent Data[%d]: 0x%02x n=%d\n",i,data[i],n);
    }
    
    return 0; 
}
///////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////
//Write ReG ��ģ���·���ֽӿڼĴ�����
s8 CLI_CmdHandler_CLIWriteReg(u8 argc, char *argv[])
{
    if(argc != 2)
    {
        return -1;
    }

    u8 cmd_c=(char)atoi(argv[0])+ 0x10; //����0 תΪ�������
    u8 cmd_v=(char)atoi(argv[1]);       //����1 תΪ���ݲ���
    
    u32 n=CMD_TIMEOUT;

    
    CS_H;
    mDelay(100);
    CS_L;
    
    AIP_SPI_WB(cmd_c);
    
    while(n>0)
    {
        if(!SDO)
        {
            AIP_SPI_WB(cmd_v);
            break;
        }
        n--;
    }
    
    CS_H;
    
    if(n==0)
    {
      printf("SPI Timeout!\n");
    }
    else
    {
      printf("\n - spi cmd>>: 0x%02x\n",cmd_c);
      printf(" - spi data>>: 0x%02x\n",cmd_v);
      printf(" - Reg#%s updated!\n",argv[0]);
    }
          
 
   
    
    return 0;
}
/////Write ReG ��ģ���·���ֽӿڼĴ�����
/////END OF :s8 CLI_CmdHandler_CLIWriteReg(u8 argc, char *argv[])
//////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//Remove AiP Data, ���AiP���ݣ� DET �� ��������
s8 CLI_CmdHandler_CLIRmAiPData(u8 argc, char *argv[])
{
    if(argc != 1)
    {
        return -1;
    }
  
    //1.�ж������Ƿ���ȷ�����ڣ�
    u16 i=0;
    u8 nCode;
    for (i=0;i<CMD_NUM;i++)
    {
        if( !strcmp(CMD[i], argv[0]) )
        {
            nCode=i;
            break;
        }
    }
    if(i==CMD_NUM)
    {
        printf("Command not exist!\n");
        return -1;
    }
    
    //2.��������
    switch(CMD_CODE[nCode])
    {
    case 0x06:  //DET
      Det=0x01;
      break;
    case 0x08:  //DD
      for(i=0;i<sz[nCode];i++)
      {
        Dd[i]=0x00;
      }
      break;
    }
    
    
    //3.���ʹ�������
    u32 n=CMD_TIMEOUT;
    
    CS_H;
    mDelay(100);
    CS_L;
    
    AIP_SPI_WB(WR|CMD_CODE[nCode]);
    
    //д������   
    for(i=0;i<sz[nCode];i++)
    {
        
          n=CMD_TIMEOUT;
          while(n>0)
          {
              if(!SDO)
              {
                  AIP_SPI_WB((u8)pDATA[nCode][i]);
                  break;
              }
              n--;
          }
          if(n==0)
          {
            printf("SPI Timeout!\n");
            break;
          }
    }
    CS_H;
    
    if(n==0)
    {
        printf("Command not fullfiled correctly!!\n");
        return -1;
    }
    printf("\n - spi cmd>>: 0x%02x\n",WR|CMD_CODE[nCode]);
    for(int i=0;i<sz[nCode];i++)
    {
        printf(" - spi data>>[%d]: 0x%02x\n",i,pDATA[nCode][i]);
    }
 	
    return 0;
}
//END OF�� s8 CLI_CmdHandler_CLIRmAiPData(u8 argc, char *argv[])

///////////////////////////////////////////////////////////////////////////////
//SPI test
s8 CLI_CmdHandler_CLISPItest(u8 argc, char *argv[])
{
    if(argc != 0)
    {
        return -1;
    }

    u16 i=0;
    u8 nCode=0; //read TH but will not be completed

    
    u32 n=CMD_TIMEOUT;
    
    CS_H;
    mDelay(100);
    CS_L;
    
    AIP_SPI_WB(RD|CMD_CODE[nCode]);
   
    for(i=0;i<sz[nCode]-1;i++)
    {
        
          n=CMD_TIMEOUT;
          while(n>0)
          {
              if(!SDO)
              {
                   pDATA[nCode][i]=AIP_SPI_RB();
                   break;
              }
              n--;
          }
          if(n==0)
          {
            printf("SPI Timeout!\n");
            break;
          }
    }

    printf("SPI test completed!\n");

    
    return 0;
}
//END OF: //Read AiP
//END OF�� s8 CLI_CmdHandler_CLIReadAiP(u8 argc, char *argv[])
///////////////////////////////////////////////////////////////////////////////

__CLI_TOP_ENTRY(CLISystemReset,         "RESET",    0);
__CLI_TOP_ENTRY(CLIReadMemory,          "READ",      0);
__CLI_TOP_ENTRY(CLIReadSPIReg8,         "SPI1",      0);
__CLI_TOP_ENTRY(CLIReadSPIRegXByte,     "RD.TH",      0);
__CLI_TOP_ENTRY(CLIWriteSPIRegXByte,    "WR.TH",      0);
__CLI_TOP_ENTRY(CLIReadAiP,           "R",     2);
__CLI_TOP_ENTRY(CLIWriteAiP,          "W",     1000);
__CLI_TOP_ENTRY(CLISetAiPMode,        "SMD",     1);
__CLI_TOP_ENTRY(CLIWriteReg,          "WREG",     2);
__CLI_TOP_ENTRY(CLIRmAiPData,          "RM",     1);            //"RM DET" or "RM DD"
__CLI_TOP_ENTRY(CLISPItest,          "SPIX",     0);            //"RM DET" or "RM DD"


/* �Զ������          -------------------------------------------------------*/

/* �Զ��庯������      -------------------------------------------------------*/

//void RCC_Configuration(void);
//void GPIO_Configuration(void);

void ADC_Configuration(void);

/*******************************************************************************
* ������  	: main
* ��������    	: ������
* �������    : ��
* ������    : ��
* ����ֵ      : ��
*******************************************************************************/
int main(void)
{
    vu16 i = 0;	
    vu32 n = 2000000;
    
    //��ʼ��ʱ�ӣ�GPIO�����ڡ�����
    Board_LowLevelInit();
    ADC_Configuration();
  
  
    //�����г�ʼ��
    __CLI_INIT();                                   //��ʼ����������� (Echo �� M.VER)
    __CLI_ADDENTRY(CLISystemReset);                 //���������������  __CLI_TOP_ENTRY(CLISystemReset,"RESET",0);
    __CLI_ADDENTRY(CLIReadMemory);                  //���������������  __CLI_TOP_ENTRY(CLIReadMemory, "READ", 0);
    __CLI_ADDENTRY(CLIReadSPIReg8);                 //���������������  __CLI_TOP_ENTRY(CLIReadSPIReg8,     "SPI1",      0);
    __CLI_ADDENTRY(CLIReadSPIRegXByte);             //���������������  __CLI_TOP_ENTRY(CLIReadSPIRegXByte, "SPI2",      0);
    __CLI_ADDENTRY(CLIWriteSPIRegXByte);            //���������������  __CLI_TOP_ENTRY(CLIWriteSPIRegXByte,    "WR.TH",      0);
    __CLI_ADDENTRY(CLIWriteAiP);                        //���������������  __CLI_TOP_ENTRY(CLIWriteSAiP,    "W",      1);
    __CLI_ADDENTRY(CLIReadAiP);                         //���������������  __CLI_TOP_ENTRY(CLIReadSAiP,    "R",      1);
    __CLI_ADDENTRY(CLISetAiPMode);                      //���������������  __CLI_TOP_ENTRY(CLISetAiPMode,  "SMD",      1);
    __CLI_ADDENTRY(CLIWriteReg);                        //__CLI_TOP_ENTRY(CLIWriteReg,          "WREG",     2);
    __CLI_ADDENTRY(CLIRmAiPData);                       //"RM DET" or "RM DD"
    __CLI_ADDENTRY(CLISPItest);                       //"RM DET" or "RM DD"
    
    InitData();
  
    LED0_ON;
    LED1_OFF;
    mDelay(500);
  
    
    LED1_ON;
    LED0_OFF;
    mDelay(500);
    
    LED0_ON;
    LED1_OFF;
    mDelay(500);
    
    /////////////////////////////////////////////////
    //Flash Programing
    u32 cnt = 0;
    u16 data[5] = {0x0002, 0x0004, 0x0003, 0x0008, 0x000A};	
    
    /* ���� HSI */
    RCC_HSICmd(ENABLE);
    /* ���� FLASH ���ƿ�*/
    FLASH_Unlock();
    /* ���һЩ��־λ */
    FLASH_ClearFlag(FLASH_FLAG_EOP | FLASH_FLAG_PGERR | FLASH_FLAG_WRPRTERR);
    /* ������ʼ��ַΪ 0x8005000 �� FLASH ҳ */
    FLASH_ErasePage(0x8005000);

    /* �� 0x8005000 ��ַ��ʼ������ FLASH д�� 5 �� ���ֿ��ȣ�16λ������ */
    do											   
    {
            FLASH_ProgramHalfWord((0x8005000 + cnt * 2), data[cnt]);
            cnt++;
    }while(cnt != 5);
    /* ���� FLASH ���ƿ�*/
    FLASH_Lock();
    //End of Flash Programming
    //////////////////////////////////////
        
//      AIP_RESET();
//      u16 ID=Get_ID();
//      u16 n=ID;
        
//    float VolValue=0;
    while(1)
    {	
        LED0_ON;
        LED1_OFF;
        mDelay(1000);
        
        LED0_OFF;
        LED1_ON;
        mDelay(1000);
        
//      VolValue = 2.56 * ADC_GetConversionValue(ADC1) / 0X0FFF;
//      printf( "\r\nThe current VolValue = %.2fv\r\n", VolValue);
    }
}


/*******************************************************************************
* ������  	: ADC_Configuration
* ��������    	: ��ʼ��������ADCת��
* �������      : ��
* ������      : ��
* ����ֵ        : ��
*******************************************************************************/

void ADC_Configuration(void)
{
	/* ���� ADC ��ʼ���ṹ�� ADC_InitStructure */
	ADC_InitTypeDef ADC_InitStructure;
	
	/* ����ADCʱ�ӷ�Ƶ */
	RCC_ADCCLKConfig(RCC_PCLK2_Div4);

	/*	
	*	��������ģʽ;
	*	��ͨ��ɨ��ģʽ;
	*	����ģ��ת��ģʽ;
	*	ת��������ʽ��ת����������������;
	*	ADC �����Ҷ��� ;
	*	���й���ת���� ADC ͨ������ĿΪ1; 
	*/
	ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;
	ADC_InitStructure.ADC_ScanConvMode = ENABLE;
	ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;
	ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;
	ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
	ADC_InitStructure.ADC_NbrOfChannel = 1;
	ADC_Init(ADC1, &ADC_InitStructure);
	
	/* ���� ADC1 ʹ��8ת��ͨ����ת��˳��1������ʱ��Ϊ 55.5 ���� */ 
	ADC_RegularChannelConfig(ADC1, ADC_Channel_14, 1, ADC_SampleTime_55Cycles5);
	/* ʹ�� ADC1 */
	ADC_Cmd(ADC1, ENABLE);
	/* ��λ ADC1 ��У׼�Ĵ��� */   
	ADC_ResetCalibration(ADC1);
	/* �ȴ� ADC1 У׼�Ĵ�����λ��� */
	while(ADC_GetResetCalibrationStatus(ADC1));
	/* ��ʼ ADC1 У׼ */
	ADC_StartCalibration(ADC1);
	/* �ȴ� ADC1 У׼��� */
	while(ADC_GetCalibrationStatus(ADC1));
	/* ���� ADC1 ת�� */ 
	ADC_SoftwareStartConvCmd(ADC1, ENABLE);	
}




